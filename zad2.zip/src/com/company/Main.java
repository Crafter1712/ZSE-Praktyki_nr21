package com.company;

import static java.lang.Math.*;
import java.util.Scanner; //wpisywanie przez urzytkownika
public class Main {

    public static void main(String[] args) {
	// write your code here
        double a1, a2, a3, a4, a5, a6, wynik;
        a1 = 9.5;
        a2 = 4.5;
        a3 = 2.5;
        a4 = 3;
        a5 = 45.5;
        a6 = 3.5;
        wynik =((a1 * a2) - (a3 * a4))/(a5 - a6) ;
        System.out.println(wynik);


    }
}
