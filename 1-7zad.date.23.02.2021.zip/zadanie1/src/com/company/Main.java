package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
    System.out.println("Ania");
    System.out.println("Basia");
    System.out.println("Kasia");
    }
}
