package com.company;

public class zadanie1 {
}
