package com.company;

public class zadanie6 {
}
