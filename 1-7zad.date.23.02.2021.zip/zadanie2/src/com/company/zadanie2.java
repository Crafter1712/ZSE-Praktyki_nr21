package com.company;

public class zadanie2 {
}
